import pygame
import math
import constantes
import fases
from pygame.locals import *
from sys import exit
from random import randint
import os

pygame.init()
#pygame.mixer.music.set_volume()
musica = pygame.mixer.music.load('sons/atmoseerie01.mp3.flac')
pygame.mixer.music.play(-1)

diretorio_principal = os.path.dirname(__file__)
diretorio_sprites = os.path.join(diretorio_principal, 'sprites')
diretorio_sons = os.path.join(diretorio_principal, 'sons')

tela = pygame.display.set_mode((constantes.LARGURA, constantes.ALTURA))

pygame.display.set_caption('ZombiEscape')

# Estados do jogo
TELA_INICIAL = "tela_inicial"
JOGANDO = "jogando"
PAUSADO = "pausado"
GAME_OVER = "game_over"

estado_jogo = TELA_INICIAL

sprites_personagem = pygame.image.load(os.path.join(diretorio_sprites, 'Personagem.png')).convert_alpha()

class Personagem(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self, personagem_grupo)
        self.imagens_personagem = []
        for i in range(3):
            img = sprites_personagem.subsurface((i*32,0), (32,32))
            img = pygame.transform.scale(img, (32*constantes.TAMANHO_PERSONAGEM, 32*constantes.TAMANHO_PERSONAGEM))
            self.imagens_personagem.append(img)

        self.vidas = 5
        self.inventario = {'chaves': 0}
            
        self.x = constantes.POSICAO_PERSONAGEM[0]
        self.y = constantes.POSICAO_PERSONAGEM[1] 
        self.posicao = constantes.POSICAO_PERSONAGEM
        self.vel = constantes.VELOCIDADE_PERSONAGEM
        self.index_lista = 0
        self.image = self.imagens_personagem[self.index_lista]
        self.rect = self.image.get_rect()
        self.rect.center = (self.posicao)

        self.mask = pygame.mask.from_surface(self.image)
        #self.radius = 25

    def update(self):
        if self.index_lista > 2:
            self.index_lista = 0
        
        self.index_lista += 0.25
        self.image = self.imagens_personagem[int(self.index_lista)]
        self.mask = pygame.mask.from_surface(self.image)
    
        self.walk()
        
        self.rect.center = (self.x, self.y)

    def walk(self):
        if pygame.key.get_pressed()[K_a] or pygame.key.get_pressed()[K_LEFT]:
            self.x -= self.vel
            self.rect.center = (self.x, self.y)
            if self.colidir_solidos():
                self.x += self.vel
                self.rect.center = (self.x, self.y)

        if pygame.key.get_pressed()[K_d] or pygame.key.get_pressed()[K_RIGHT]:
            self.x += self.vel
            self.rect.center = (self.x, self.y)
            if self.colidir_solidos():
                self.x -= self.vel
                self.rect.center = (self.x, self.y)

        if pygame.key.get_pressed()[K_w] or pygame.key.get_pressed()[K_UP]:
            self.y -= self.vel
            self.rect.center = (self.x, self.y)
            if self.colidir_solidos():
                self.y += self.vel
                self.rect.center = (self.x, self.y)

        if pygame.key.get_pressed()[K_s] or pygame.key.get_pressed()[K_DOWN]:
            self.y += self.vel
            self.rect.center = (self.x, self.y)
            if self.colidir_solidos():
                self.y -= self.vel
                self.rect.center = (self.x, self.y)
    
    def colidir_solidos(self):
        solidos_list = solidos.sprites()
        for solido in solidos_list:
            if solido != self and pygame.sprite.collide_mask(self, solido):
                # overlap = (pygame.math.Vector2(self.rect.center)-(25,50)) - pygame.math.Vector2(solido.rect.center)
                # if overlap.length() > 0:
                #     overlap = overlap.normalize() * self.vel
                #     self.x -= overlap.x
                #     self.y -= overlap.y
                #     self.rect.center = (self.x, self.y) 
                return True   

    def empurrado(self, direcao, forca=10):
        if direcao.length() > 0:
            direcao = direcao.normalize() * forca
            self.rect.center += direcao

    def draw_mask(self, surface):
        mask_offset = (self.rect.x, self.rect.y)
        for x, y in self.mask.outline():
            pygame.draw.circle(surface, (255,0,0), (x + mask_offset[0], y + mask_offset[1]), 1)

class Zumbi(pygame.sprite.Sprite):
    def __init__(self, posicao):
        pygame.sprite.Sprite.__init__(self, inimigos_grupo,  todas_as_sprites, solidos)
        self.imagens_zumbi = []
        for i in range(3):
            img = sprites_personagem.subsurface((i*32,32), (32,32))
            img = pygame.transform.scale(img, (32*constantes.TAMANHO_ZUMBI, 32*constantes.TAMANHO_ZUMBI))
            self.imagens_zumbi.append(img)
        self.posicao = posicao
        self.vel = constantes.VELOCIDADE_ZUMBI
        self.index_lista = 0
        self.image = self.imagens_zumbi[self.index_lista]
        self.rect = self.image.get_rect()
        self.rect.center = self.posicao
        self.som = pygame.mixer.Sound('sons/Large Monster Death 01.wav')
        self.som.set_volume(0.5)
        self.wait_time = 0

        self.mask = pygame.mask.from_surface(self.image)

        self.direcao = pygame.math.Vector2()
        self.velocity = pygame.math.Vector2()

    def perseguir(self):
        vetor_personagem = pygame.math.Vector2(personagem.rect.center)
        vetor_zumbi = pygame.math.Vector2(self.rect.center)
        distancia = self.get_distancia_vetor(vetor_personagem, vetor_zumbi)

        if distancia > 0:
            self.direcao = (vetor_personagem - vetor_zumbi).normalize()
        else:
            self.direcao = pygame.math.Vector2()

        self.velocity = self.direcao * self.vel
        self.posicao += self.velocity

        self.rect.centerx = self.posicao.x
        self.rect.centery = self.posicao.y

    def get_distancia_vetor(self, vetor_personagem, vetor_zumbi):
        return (vetor_personagem - vetor_zumbi).magnitude()

    def draw_mask(self, surface):
        mask_offset = (self.rect.x, self.rect.y)
        for x, y in self.mask.outline():
            pygame.draw.circle(surface, (255,0,0), (x + mask_offset[0], y + mask_offset[1]), 1)

    def colidir_solidos(self):
        #personagem = personagem_grupo.sprites()
        solidos_list = solidos.sprites()
        # for p in personagem:
        #     solidos_list.append(p)
        for solido in solidos_list:
            if solido != self and pygame.sprite.collide_mask(self, solido):
                overlap = pygame.math.Vector2(self.rect.center) - pygame.math.Vector2(solido.rect.center)
                if overlap.length() > 0:
                    overlap = overlap.normalize() * self.vel
                    self.posicao += overlap
                    self.rect.center = self.posicao 
                return True   

    def update(self):
        if self.index_lista > 2:
            self.index_lista = 0
        self.index_lista += 0.25
        self.image = self.imagens_zumbi[int(self.index_lista)]
        
        if self.wait_time > 0:
            self.wait_time -=1
        else:
            self.perseguir()

        if pygame.sprite.collide_mask(self, personagem):
            #direcao = pygame.math.Vector2(personagem.rect.center) - pygame.math.Vector2(self.rect.center)
            #personagem.empurrado(direcao, forca=50)
            self.wait_time = 30
            self.som.play()
        self.colidir_solidos()

# FUNÇÃO PARA CALCULAR A DIREÇÃO DO MOVIMENTO
def get_direction(source, target):
    dx = target[0] - source[0]
    dy = target[1] - source[1]
    distance = math.sqrt(dx ** 2 + dy ** 2)
    if distance == 0:
        return 0, 0
    return dx / distance, dy / distance

class Besta:
    def __init__(self, x, y, width, height, speed, attack_cooldown):
        self.rect = pygame.Rect(x, y, width, height)
        self.speed = speed
        self.target = None
        self.attack_cooldown = attack_cooldown  # Tempo de espera entre ataques
        self.last_attack_time = pygame.time.get_ticks()
        self.direction = (0, 0)
        self.attacking = False

    def attack(self, player, walls):
        current_time = pygame.time.get_ticks()

        # Se não está atacando e o cooldown passou, define um novo alvo
        if not self.attacking and current_time - self.last_attack_time > self.attack_cooldown:
            self.target = player.center
            self.direction = get_direction(self.rect.center, self.target)
            self.attacking = True

        # Move-se em direção ao alvo, se atacando
        if self.attacking:
            self.rect.x += self.direction[0] * self.speed
            self.rect.y += self.direction[1] * self.speed

            # Verifica colisão com as paredes
            for wall in walls:
                if self.rect.colliderect(wall):
                    self.stop_attack()
                    return

    def stop_attack(self):
        self.attacking = False
        self.target = None
        self.last_attack_time = pygame.time.get_ticks()

    


class Chave(pygame.sprite.Sprite):
    def __init__(self, posicao):
        pygame.sprite.Sprite.__init__(self, todas_as_sprites, coletaveis_grupo)
        image = pygame.image.load(os.path.join(diretorio_sprites, 'chave.png')).convert_alpha()
        self.image = pygame.transform.scale(image, (32*2, 32*2))
        self.rect = self.image.get_rect()
        self.posicao = posicao
        self.rect.center = self.posicao
        self.som = pygame.mixer.Sound('sons\key2_pickup.wav')

        self.mask = pygame.mask.from_surface(self.image)
        #self.radius = 15

    def update(self):
        self.rect.center = self.posicao
        self.image = pygame.transform.scale(self.image, (32*2, 32*2))

    def draw_mask(self, surface):
        mask_offset = (self.rect.x, self.rect.y)
        for x, y in self.mask.outline():
            pygame.draw.circle(surface, (255,0,0), (x + mask_offset[0], y + mask_offset[1]), 1)

class Obstaculo(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        pygame.sprite.Sprite.__init__(self, solidos)
        self.image = pygame.Surface((constantes.TAMANHO_OBSTACULO, constantes.TAMANHO_OBSTACULO))
        self.image.fill(constantes.MARROM)
        self.rect = self.image.get_rect(center=(x, y))
        self.mask = pygame.mask.from_surface(self.image)

    def draw_mask(self, surface):
        mask_offset = (self.rect.x, self.rect.y)
        for x, y in self.mask.outline():
            pygame.draw.circle(surface, (255,0,0), (x + mask_offset[0], y + mask_offset[1]), 1)

# FUNÇÃO PARA DESENHAR A FASE COM BASE NO ARRAY
def desenhar_fase(fase_data, todas_as_sprites, player):
    for sprite in todas_as_sprites:
        sprite.kill()
    todas_as_sprites.empty()
    for row in range(len(fase_data)):
        for col in range(len(fase_data[row])):
            x = col * 50  # Posição x no cenário
            y = row * 50  # Posição y no cenário
            if fase_data[row][col] == 1:
                # Adiciona um obstáculo na posição
                obstaculo = Obstaculo(x, y)
                todas_as_sprites.add(obstaculo)
            elif fase_data[row][col] == 2:
                # Adiciona o jogador na posição inicial
                zumbi = Zumbi((x,y))
            elif fase_data[row][col] == 3:
                chave = Chave((x,y))

def apagar_personagem(array):
    for i in array:
        for j in i:
            if i[j] == 2:
                print(array)
                i[j] = 0
                print(array)

#CRIANDO GRUPOS E INSANCIANDO OBJETOS
personagem_grupo = pygame.sprite.Group()
coletaveis_grupo = pygame.sprite.Group()
todas_as_sprites = pygame.sprite.Group()
solidos = pygame.sprite.Group()
inimigos_grupo = pygame.sprite.Group()
#chave = Chave((constantes.X_CHAVE,constantes.Y_CHAVE))
personagem = Personagem()
#zumbi = Zumbi((500,100))
#z2 = Zumbi((100,500))
sala_inicial = fases.fase1
desenhar_fase(sala_inicial.array, todas_as_sprites, personagem)
sala_atual = sala_inicial

font = pygame.font.Font(None, 36)
relogio = pygame.time.Clock()
rodando = True

#LOOP PRINCIPAL DO JOGO
while rodando:
    relogio.tick(30)
    tela.fill(constantes.PRETO)
    for event in pygame.event.get():
        if event.type == QUIT:
            rodando = False

    #     if estado_jogo == TELA_INICIAL:
    #         if event.type == pygame.KEYDOWN:
    #             if event.key == pygame.K_RETURN:  # Enter para iniciar
    #                 estado_jogo = JOGANDO

    #     elif estado_jogo == JOGANDO:
    #         if event.type == pygame.KEYDOWN:
    #             if event.key == pygame.K_p:  # P para pausar
    #                 estado_jogo = PAUSADO

    #     elif estado_jogo == PAUSADO:
    #         if event.type == pygame.KEYDOWN:
    #             if event.key == pygame.K_p:  # P para despausar
    #                 estado_jogo = JOGANDO
    #             elif event.key == pygame.K_q:  # Q para sair
    #                 rodando = False

    #     elif estado_jogo == GAME_OVER:
    #         if event.type == pygame.KEYDOWN:
    #             if event.key == pygame.K_RETURN:  # Enter para reiniciar
    #                 desenhar_fase(sala_inicial.array,todas_as_sprites,personagem)
    #                 personagem.posicao = constantes.POSICAO_PERSONAGEM
    #                 sala_atual = sala_inicial
    #                 estado_jogo = TELA_INICIAL

    # if estado_jogo == TELA_INICIAL:
    #     texto_tela_inicial = font.render("ZOMBIESCAPE", True, (255,255,255))
    #     texto_tela_inicial2 = font.render("Pressione Enter para começar", True, (255,255,255))

    #COLETANDO ITENS
    coletou = pygame.sprite.spritecollide(personagem, coletaveis_grupo, False, pygame.sprite.collide_mask)
    if coletou:
        coletou[0].posicao = (randint(40, 600), randint(50, 430))
        coletou[0].som.play()
        personagem.inventario['chaves'] += 1
        print(personagem.inventario['chaves'])

    # #COLIDINDO COM ZUMBIS
    if pygame.sprite.spritecollide(personagem, inimigos_grupo, False, pygame.sprite.collide_mask):
        personagem.vidas -= 1
        pygame.time.delay(100)
        if personagem.vidas <= 0:
            print("GAME OVER")
            rodando = False

    if personagem.x > 960 and "direita" in sala_atual.conexoes:
        sala_atual = sala_atual.conexoes["direita"]
        personagem.x = 0
        apagar_personagem(sala_atual.array)
        desenhar_fase(sala_atual.array, todas_as_sprites, personagem)
        if sala_atual.som:
            sala_atual.som.play()
    elif personagem.x < 0 and "esquerda" in sala_atual.conexoes:
        sala_atual = sala_atual.conexoes["esquerda"]
        personagem.x = 960
        apagar_personagem(sala_atual.array)
        desenhar_fase(sala_atual.array, todas_as_sprites, personagem)
        if sala_atual.som:
            sala_atual.som.play()
    elif personagem.y < 0 and "cima" in sala_atual.conexoes:
        sala_atual = sala_atual.conexoes["cima"]
        personagem.y = 720
        apagar_personagem(sala_atual.array)
        desenhar_fase(sala_atual.array, todas_as_sprites, personagem)
        if sala_atual.som:
            sala_atual.som.play()
    elif personagem.y > 720 and "baixo" in sala_atual.conexoes:
        sala_atual = sala_atual.conexoes["baixo"]
        personagem.y = 0
        apagar_personagem(sala_atual.array)
        desenhar_fase(sala_atual.array, todas_as_sprites, personagem)
        if sala_atual.som:
            sala_atual.som.play()

    
    todas_as_sprites.draw(tela)
    personagem_grupo.draw(tela)
    personagem.draw_mask(tela)
    # for obj in solidos.sprites():
    #     obj.draw_mask(tela)
    #pygame.draw.rect(tela, (255,0,0), chave, 2)
    # personagem.draw_mask(tela)
    # chave.draw_mask(tela)
    # zumbi.draw_mask(tela)
    # z2.draw_mask(tela)
    todas_as_sprites.update()
    personagem_grupo.update()

    mensagem = font.render(f"Chaves: {personagem.inventario['chaves']}     Vidas: {personagem.vidas}", True, (255,255,255))
    fase_texto = font.render(f"Fase: {sala_atual.nome}",True,(255,255,255))
    tela.blit(mensagem, (420,40))
    tela.blit(fase_texto,(420,700))


    #pygame.display.update()
    pygame.display.flip()
