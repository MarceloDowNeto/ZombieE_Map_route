from random import randint

#Contastes da tela
LARGURA =960
ALTURA = 720
PRETO = (0,0,0)
MARROM = (139, 69, 19)

#Constantes personagem
POSICAO_PERSONAGEM = LARGURA/2, 500
TAMANHO_PERSONAGEM = 5
VELOCIDADE_PERSONAGEM = 10

#Constantes Zumbi
TAMANHO_ZUMBI = 5
VELOCIDADE_ZUMBI = 5

#Constantes Obstaculos
TAMANHO_OBSTACULO = 50

#Chave
X_CHAVE = randint(40, 600)
Y_CHAVE = randint(50, 430)

