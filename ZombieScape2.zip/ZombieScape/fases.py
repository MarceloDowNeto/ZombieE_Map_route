import pygame
import sys
from collections import deque
import constantes

pygame.init()

tela = pygame.display.set_mode((constantes.LARGURA, constantes.ALTURA))
clock = pygame.time.Clock()

som_sala_monstro = pygame.mixer.Sound('sons/HorrorCinema3.wav')

class Fase:
    todas_as_fases = []
    def __init__(self, nome, array, som=None):
        self.nome = nome
        self.conexoes = {}  # Conexões da fase (e.g., {"direita": fase2})
        self.array = array
        self.som = som
        self.objetos_coletados = set()
        Fase.todas_as_fases.append(self)

    def adicionar_conexao(self, direcao, fase):
        self.conexoes[direcao] = fase

SALA1 = [
    [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]
]

SALA2 = [
    [1, 1, 1, 1, 1, 1, 1, 1, 1, (6,4), (6,4), 1, 1, 1, 1, 1, 1, 1, 1, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 3, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1]
]

SALA3 = [
    [1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 4, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, (6,4)],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, (6,4)],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 0, 0, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1],
    [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]
]

fim = Fase('Fim',[])
fase1 = Fase('Início', SALA1)
fase2 = Fase('sala2', SALA2)
fase3 = Fase('sala3', SALA3, som=som_sala_monstro)
fase4 = Fase('Sala4','SALA4')

fim.adicionar_conexao('baixo',fase1)
# fase1.adicionar_conexao('cima',fase2)
fase1.adicionar_conexao('esquerda', fase2)
fase2.adicionar_conexao('direita', fase1)
fase2.adicionar_conexao('baixo', fase3)
fase2.adicionar_conexao('esquerda',fase4)
fase3.adicionar_conexao('cima', fase2)
fase4.adicionar_conexao('direita',fase2)




# # Função para calcular posições automaticamente
# def calcular_posicoes(raiz, inicio=(constantes.LARGURA // 2, constantes.ALTURA // 7), distancia=150):
#     posicoes = {}
#     visitados = set()

#     def dfs(fase, x, y):
#         if fase in visitados:
#             return
#         visitados.add(fase)

#         # Define a posição da fase atual
#         posicoes[fase] = (x, y)

#         # Calcula as posições das conexões
#         for direcao, proxima_fase in fase.conexoes.items():
#             if proxima_fase not in visitados:
#                 if direcao == "cima":
#                     dfs(proxima_fase, x, y - distancia)
#                 elif direcao == "baixo":
#                     dfs(proxima_fase, x, y + distancia)
#                 elif direcao == "esquerda":
#                     dfs(proxima_fase, x - distancia, y)
#                 elif direcao == "direita":
#                     dfs(proxima_fase, x + distancia, y)

#     # Começa pela fase inicial (raiz)
#     dfs(raiz, inicio[0], inicio[1])
#     return posicoes

# # Calcular posições das fases (começando na fase1)
# posicoes = calcular_posicoes(fase1)

# # Função para encontrar o caminho entre dois nós usando BFS
# def encontrar_caminho(inicio, destino):
#     visitados = set()
#     fila = deque([(inicio, [])])  # (fase_atual, caminho_atual)

#     while fila:
#         fase_atual, caminho = fila.popleft()

#         if fase_atual in visitados:
#             continue

#         visitados.add(fase_atual)
#         novo_caminho = caminho + [fase_atual]

#         if fase_atual == destino:
#             return novo_caminho

#         for proxima_fase in fase_atual.conexoes.values():
#             if proxima_fase not in visitados:
#                 fila.append((proxima_fase, novo_caminho))

#     return None  # Não há caminho

# # Função para desenhar o grafo
# def desenhar_grafo(tela, posicoes, selecionados):
    
#     # Cores e fontes
#     cor_fase = (255, 255, 255)
#     cor_dourado = (255, 215, 0)
#     cor_vermelho = (255, 0, 0)
#     cor_conexao = (255, 255, 255)
#     cor_caminho = (255, 0, 0)
#     fonte = pygame.font.Font(None, 24)

#     # Desenhar conexões
#     for fase in posicoes:
#         x, y = posicoes[fase]
#         for direcao, proxima_fase in fase.conexoes.items():
#             if proxima_fase in posicoes:
#                 destino_x, destino_y = posicoes[proxima_fase]
#                 pygame.draw.line(tela, cor_conexao, (x, y), (destino_x, destino_y), 2)

#     # Desenhar caminho se houver dourado e vermelho
#     if selecionados["dourado"] and selecionados["vermelho"]:
#         caminho = encontrar_caminho(selecionados["dourado"], selecionados["vermelho"])
#         if caminho:
#             for i in range(len(caminho) - 1):
#                 x1, y1 = posicoes[caminho[i]]
#                 x2, y2 = posicoes[caminho[i + 1]]
#                 pygame.draw.line(tela, cor_caminho, (x1, y1), (x2, y2), 3)

#     # Desenhar fases
#     for fase, (x, y) in posicoes.items():
#         # Determinar cor com base nos selecionados
#         if fase == selecionados["dourado"]:
#             cor = cor_dourado
#         elif fase == selecionados["vermelho"]:
#             cor = cor_vermelho
#         else:
#             cor = cor_fase

#         pygame.draw.circle(tela, cor, (x, y), 20)
#         texto = fonte.render(fase.nome, True, (0, 0, 0))
#         texto_rect = texto.get_rect(center=(x, y))
#         tela.blit(texto, texto_rect)

# # Função para detectar clique em um nó
# def detectar_clique(posicoes, mouse_pos):
#     for fase, (x, y) in posicoes.items():
#         if (x - mouse_pos[0]) ** 2 + (y - mouse_pos[1]) ** 2 <= 20 ** 2:
#             return fase
#     return None

# # Dicionário para gerenciar seleções
# selecionados = {"dourado": None, "vermelho": None}

# # Loop principal
# while True:
#     for evento in pygame.event.get():
#         if evento.type == pygame.QUIT:
#             pygame.quit()
#             sys.exit()

#         if evento.type == pygame.MOUSEBUTTONDOWN:
#             # Detectar clique
#             clicado = detectar_clique(posicoes, pygame.mouse.get_pos())
#             if clicado:
#                 # Regras de seleção
#                 if clicado == selecionados["dourado"]:
#                     # Se clicar no dourado, desmarca
#                     selecionados["dourado"] = None
#                 elif clicado == selecionados["vermelho"]:
#                     # Se clicar no vermelho, desmarca
#                     selecionados["vermelho"] = None
#                 elif selecionados["dourado"] is None:
#                     # Marca como dourado se não houver dourado
#                     selecionados["dourado"] = clicado
#                 elif selecionados["vermelho"] is None:
#                     # Marca como vermelho se não houver vermelho
#                     selecionados["vermelho"] = clicado

#     # Limpar tela
#     tela.fill((0, 0, 0))

#     # Desenhar o grafo
#     desenhar_grafo(tela, posicoes, selecionados)

#     pygame.display.flip()
#     clock.tick(60)
