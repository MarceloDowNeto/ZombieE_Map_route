import pygame
from pygame.locals import *
import os

pasta_sprites = os.path.join(os.path.dirname(__file__), 'sprites')
sprites_personagem = pygame.image.load(os.path.join(pasta_sprites, 'Personagem.png')).convert_alpha()

class Personagem(pygame.sprite.Sprite):
    def __init__(self):
        pygame.sprite.Sprite.__init__(self)
        self.imagens_personagem = []
        for i in range(3):
            img = sprites_personagem.subsurface((i*32,0), (32,32))
            img = pygame.transform.scale(img, (32*5, 32*5))
            self.imagens_personagem.append(img)
            
        self.x = 200
        self.y = 100
        self.vel = 10
        self.index_lista = 0
        self.image = self.imagens_personagem[self.index_lista]
        self.rect = self.image.get_rect()
        self.rect.center = (self.x, self.y)

    def update(self):
        if self.index_lista > 2:
            self.index_lista = 0
        
        self.index_lista += 0.25
        self.image = self.imagens_personagem[int(self.index_lista)]
        self.walk()
        self.rect.center = (self.x, self.y)

    def walk(self):
        if pygame.key.get_pressed()[K_a]:
            self.x -= self.vel

        if pygame.key.get_pressed()[K_d]:
            self.x += self.vel

        if pygame.key.get_pressed()[K_w]:
            self.y -= self.vel

        if pygame.key.get_pressed()[K_s]:
            self.y += self.vel